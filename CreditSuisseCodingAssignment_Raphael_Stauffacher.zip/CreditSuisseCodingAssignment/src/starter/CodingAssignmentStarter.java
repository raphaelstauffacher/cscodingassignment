package starter;

import java.util.ArrayList;
import java.util.HashMap;

import logic.CodingAssignment;
import logic.Event;
import logic.EventResult;

public class CodingAssignmentStarter {

	/**
	 * default log file path
	 */
	private static String logfilePath = "C:\\data\\logfile.txt";
	
	/**
	 * default result file path
	 */
	private static String resultfilePath = "C:\\data\\result.txt";

	/**
	 * main method sets log file path arguments if available, otherwise default
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length != 0) {
			setLogfilePath(args[0]);
		}
		if (args.length > 1) {
			setResultfilePath(args[1]);
		}
		new CodingAssignmentStarter();
	}

	/**
	 * starts calling CodingAssignment functions
	 */
	public CodingAssignmentStarter() {
		CodingAssignment codingAssignment = new CodingAssignment();
		HashMap<Integer, String> logfileContent = codingAssignment.readLogFile(getLogfilePath());
		ArrayList<Event> events = codingAssignment.parseLogFileContentIntoArray(logfileContent);
		ArrayList<EventResult> eventResults = codingAssignment.calculateEventDurationAndProcessResults(events);
		codingAssignment.saveEventResults(eventResults);
	}

	public static String getLogfilePath() {
		return logfilePath;
	}

	public static void setLogfilePath(String logfilePath) {
		CodingAssignmentStarter.logfilePath = logfilePath;
	}

	public static String getResultfilePath() {
		return resultfilePath;
	}

	public static void setResultfilePath(String resultfilePath) {
		CodingAssignmentStarter.resultfilePath = resultfilePath;
	}
	
}
