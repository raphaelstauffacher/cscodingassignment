package test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import logic.CodingAssignment;
import logic.Event;
import logic.EventResult;
import starter.CodingAssignmentStarter;

/**
 * Testing the program 'CodingAssignment'
 * @author Raphael
 *
 */
public class CodingAssignmentTest {
	
	/**
	 * function to get event results for JUnit tests
	 * @return eventResultArrayList
	 */
	private ArrayList<EventResult> getEventResultsForTest() {
		CodingAssignment codingAssignment = new CodingAssignment();
		HashMap<Integer, String> logfileContent = codingAssignment.readLogFile(CodingAssignmentStarter.getLogfilePath());
		ArrayList<Event> events = codingAssignment.parseLogFileContentIntoArray(logfileContent);
		return codingAssignment.calculateEventDurationAndProcessResults(events);
	}

	/**
	 * JUnit test to check if duration result is calculated correctly
	 */
	@Test
	public void testDurationResult() {
		EventResult toBeTestedResult = null;
		for (EventResult e : getEventResultsForTest()) {
			if (e.getId().equals("scsmbstgra")) {
				toBeTestedResult = e;
			}
		}
		assertEquals(5l, toBeTestedResult.getDuration());
	}

	/**
	 * JUnit test to check if the correct event is flagged as too long
	 */
	@Test
	public void testProcessResultNotFlagged() {
		EventResult toBeTestedResult = null;
		for (EventResult e : getEventResultsForTest()) {
			if (e.getId().equals("scsmbstgrb")) {
				toBeTestedResult = e;
			}
		}
		assertEquals(false, toBeTestedResult.isAlert());
	}

	/**
	 * JUnit test to check if the correct event is flagged as normal duration
	 */
	@Test
	public void testProcessResultFlagged() {
		EventResult toBeTestedResult = null;
		for (EventResult e : getEventResultsForTest()) {
			if (e.getId().equals("scsmbstgrc")) {
				toBeTestedResult = e;
			}
		}
		assertEquals(true, toBeTestedResult.isAlert());
	}

}
