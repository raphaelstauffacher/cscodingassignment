package logic;

import java.util.Date;

/**
 * class that holds events read from log file
 * @author Raphael
 *
 */
public class Event {
	
	private String id;
	
	public static enum possibleStates {STARTED, FINISHED};
	
	private possibleStates state;
	
	private Date timestamp;
	
	private String type;
	
	private String host;
	
	/**
	 * constructor to create Event object
	 * @param id
	 * @param state
	 * @param timestamp
	 * @param type
	 * @param host
	 */
	public Event(String id, possibleStates state, Date timestamp, String type, String host) {
		setId(id);
		setState(state);
		setTimestamp(timestamp);
		setType(type);
		setHost(host);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public possibleStates getState() {
		return state;
	}

	public void setState(possibleStates state) {
		this.state = state;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

}
