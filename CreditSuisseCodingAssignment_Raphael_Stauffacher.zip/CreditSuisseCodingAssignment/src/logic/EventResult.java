package logic;

/**
 * class that holds event results
 * @author Raphael
 *
 */
public class EventResult {
	
	private String id;
	
	private long duration;
	
	private String type;
	
	private String host;
	
	private boolean alert;
	
	/**
	 * constructor to create EventResult object
	 * @param id
	 * @param duration
	 * @param type
	 * @param host
	 * @param alert
	 */
	public EventResult(String id, long duration, String type, String host, boolean alert) {
		setId(id);
		setDuration(duration);
		setType(type);
		setHost(host);
		setAlert(alert);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public long getDuration() {
		return duration;
	}

	public void setDuration(long duration) {
		this.duration = duration;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public boolean isAlert() {
		return alert;
	}

	public void setAlert(boolean alert) {
		this.alert = alert;
	}

}
