package logic;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

import starter.CodingAssignmentStarter;
import util.FileHandler;
import util.FileReader;
import util.FileWriter;

/**
 * Class to read log file, parse contents, produce result set and save results
 * 
 * @author Raphael
 *
 */
public class CodingAssignment {

	private FileReader fileReader = new FileReader();

	private FileHandler fileHandler = new FileHandler();

	private FileWriter fileWriter = new FileWriter();

	/**
	 * reads the log file from input path
	 * 
	 * @param logfilePath
	 * @return logfileContent
	 */
	public HashMap<Integer, String> readLogFile(String logfilePath) {
		HashMap<Integer, String> logfileContent = fileReader.readFile(logfilePath);
		return logfileContent;
	}

	/**
	 * parse log file contents into event array using GSON
	 * 
	 * @param logfileContent
	 * @return eventArray
	 */
	public ArrayList<Event> parseLogFileContentIntoArray(HashMap<Integer, String> logfileContent) {
		ArrayList<Event> eventArray = new ArrayList<Event>();
		for (int i = 0; i < logfileContent.size(); i++) {
			Gson g = new GsonBuilder().registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {
				public Date deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext context)
						throws JsonParseException {
					return new Date(jsonElement.getAsJsonPrimitive().getAsLong());
				}
			}).create();
			Event event = g.fromJson(logfileContent.get(i), Event.class);
			eventArray.add(event);
		}
		return eventArray;
	}

	/**
	 * calculate event duration and create event result
	 * 
	 * @param eventArray
	 * @return eventResult
	 */
	public ArrayList<EventResult> calculateEventDurationAndProcessResults(ArrayList<Event> eventArray) {
		ArrayList<String> completedCalculationsById = new ArrayList<String>();
		ArrayList<EventResult> eventResults = new ArrayList<EventResult>();
		for (Event e : eventArray) {
			String id = e.getId();
			if (!completedCalculationsById.contains(id)) {
				Date started = null;
				Date finished = null;
				for (Event innerE : eventArray) {
					if (innerE.getId().equals(id)) {
						if (innerE.getState().equals(Event.possibleStates.FINISHED)) {
							finished = innerE.getTimestamp();
						} else if (innerE.getState().equals(Event.possibleStates.STARTED)) {
							started = innerE.getTimestamp();
						}
					}
				}
				if (started != null && finished != null) {
					long duration = finished.getTime() - started.getTime();
					System.out.println("event duration for event with id " + id + " is " + duration + " ms");
					boolean alert = duration > 4l;
					eventResults.add(new EventResult(id, duration, e.getType(), e.getHost(), alert));
					completedCalculationsById.add(id);
				} else {
					System.err.println("no duration found for event id : " + id);
				}
			} else {
				System.err.println("calculation for event with id " + id + " already completed");
			}
		}
		return eventResults;
	}

	/**
	 * saves the event results into result file in JSON format
	 * 
	 * @param eventResults
	 */
	public void saveEventResults(ArrayList<EventResult> eventResults) {
		if (fileHandler.doesFileExist(CodingAssignmentStarter.getResultfilePath())) {
			fileHandler.deleteFile(CodingAssignmentStarter.getResultfilePath());
		}
		fileHandler.createFile(CodingAssignmentStarter.getResultfilePath());
		for (EventResult e : eventResults) {
			Gson g = new GsonBuilder().registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {
				public Date deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext context)
						throws JsonParseException {
					return new Date(jsonElement.getAsJsonPrimitive().getAsLong());
				}
			}).create();
			String resultJson = g.toJson(e);
			fileWriter.writeIntoFile(CodingAssignmentStarter.getResultfilePath(), resultJson + "\n", true);
		}
	}

}
