package util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.HashMap;

/**
 * Writer for Files
 * @author A466008
 *
 */
public class FileWriter {

private FileHandler fileHandler = new FileHandler();
private FileReader fileReader = new FileReader();
	
	/**
	 * Writes a text into a file
	 * @param filePath
	 * @param text
	 * @param flagExtend
	 */
	public void writeIntoFile(String filePath, String text, boolean flagExtend) {
		try {
			BufferedWriter bw = new BufferedWriter(fileHandler.openFileWriter(filePath, flagExtend));
			bw.write(text);
			bw.close();
		} catch (IOException e) {
			System.err.println("Writing into file failed...");
		}
	}
	
	/**
	 * Writes a text into a specific line of a file
	 * @param filePath
	 * @param line
	 * @param text
	 */
	public void writeSpecificLine(String filePath, int line, String text) {
		HashMap<Integer, String> file = fileReader.readFile(filePath);
		file.put(line, text);
		String textNew = "";
		for (int i = 0; i < file.size(); i++) {
			textNew += file.get(i) + "\r\n";
		}
		writeIntoFile(filePath, textNew, false);
	}

}
