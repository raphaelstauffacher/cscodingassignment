package util;

import java.io.InputStream;

/**
 * util class to load the images
 * @author A466008
 *
 */
public class FileLoader {
	
	/**
	 * default constructor
	 */
	public FileLoader() {
	}

	/**
	 * function to load a image
	 * @param filePath
	 * @return URL Object
	 */
	public InputStream loadFile(String filePath) {
		System.out.println(this.getClass().getResourceAsStream(filePath));
		return this.getClass().getClassLoader().getResourceAsStream(filePath);
	}
	
}
