package util;

import java.io.BufferedReader;
import java.util.HashMap;

/**
 * Reader for files
 * @author A466008
 *
 */
public class FileReader {
	
private FileHandler fileHandler = new FileHandler();
	
	/**
	 * Reads a file and stores the data in a line-numberated HashMap
	 * @param filePath
	 * @return fileContentHashMap
	 */
	public HashMap<Integer, String> readFile(String filePath) {
		HashMap<Integer, String> textFileLines = new HashMap<Integer, String>();
		try {
			BufferedReader br = new BufferedReader(fileHandler.openFileReader(filePath));
			
			int counter = 0;
			String line = br.readLine();
			while (line != null) {
				textFileLines.put(counter, line);
				counter++;
				line = br.readLine();
			}
			
		} catch (Exception e) {
			System.err.println("Reading from file failed...");
		}
		return textFileLines;
	}
	
}
