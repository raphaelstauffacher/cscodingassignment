package util;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Class to handle all File actions
 * @author A466008
 *
 */
public class FileHandler {
	
	/**
	 * Opens a new FileReader and returns it
	 * @param filePath
	 * @return fileReader
	 */
	public FileReader openFileReader(String filePath) {
		FileReader file = null;
		try {
			file = new FileReader(filePath);
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.err.println("Attempt to open file failed...");
		}
		return file;
	}
	
	/**
	 * Opens a new FileWriter and returns it
	 * @param filePath
	 * @param flagExtend
	 * @return fileWriter
	 */
	public FileWriter openFileWriter(String filePath, boolean flagExtend) {
		FileWriter file = null;
		try {
			file = new FileWriter(filePath, flagExtend);
		} catch (Exception e) {
			System.err.println("Attempt to open file failed...");
		}
		return file;
	}
	
	/**
	 * Opens a file in the windows explorer
	 * @param filePath
	 */
	public void openFileInExplorer(String filePath) {
		try {
			Runtime.getRuntime().exec("explorer.exe /select," + filePath);
		} catch (IOException e) {
			System.err.println("Attempt to open file in explorer failed...");
		}
	}
	
	/**
	 * Opens a new File and returns it
	 * @param filePath
	 * @return File
	 */
	public File openFile(String filePath) {
		File file = null;
		try {
			file = new File(filePath);
		} catch (Exception e) {
			System.err.println("Attempt to open file failed...");
		}
		return file;
	}
	
	/**
	 * Creates a new file
	 * @param filePath
	 */
	public void createFile(String filePath) {
		File file = null;
		try {
			file = new File(filePath);
			file.createNewFile();
		} catch (Exception e) {
			System.err.println("File creation '" + filePath + "' failed...");
		}
	}
	
	/**
	 * Creates a new directory (fullPath)
	 * @param filePath
	 */
	public void createPath(String filePath) {
		File file = null;
		try {
			file = new File(filePath);
			file.mkdirs();
		} catch (Exception e) {
			System.err.println("File creation '" + filePath + "' failed...");
		}
	}
	
	/**
	 * Deletes an existing file
	 * @param filePath
	 */
	public void deleteFile(String filePath) {
		File file = null;
		try {
			file = new File(filePath);
			file.delete();
		} catch (Exception e) {
			System.err.println("Deleting file '" + filePath + "' failed...");
		}
	}
	
	/**
	 * Checks if a file exists
	 * @param filePath
	 * @return booleanExist
	 */
	public boolean doesFileExist(String filePath) {
		if(this.openFile(filePath).exists()) {
			return true;
		}
		return false;
	}
	
}
